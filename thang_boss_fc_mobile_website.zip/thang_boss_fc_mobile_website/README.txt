THẮNG BOSS FC MOBILE — WEBSITE NEON
===================================

CÁC FILE
- index.html : nội dung và các mục website
- style.css  : giao diện neon xanh tím, responsive điện thoại/máy tính
- script.js  : link YouTube và danh sách video/Shorts mẫu

XEM THỬ TRÊN MÁY TÍNH
1. Giải nén file ZIP.
2. Mở thư mục.
3. Nhấp đúp index.html để mở bằng trình duyệt.
Không cần cài phần mềm hay viết code để xem mẫu.

CÁCH ĐƯA WEBSITE LÊN MẠNG MIỄN PHÍ BẰNG GITHUB PAGES
1. Đăng nhập hoặc tạo tài khoản tại https://github.com/
2. Tạo repository mới, ví dụ: thang-boss-fc-mobile
3. Chọn Public; nhấn Create repository.
4. Trong repository, chọn Add file > Upload files.
5. Tải lên 3 file index.html, style.css, script.js (có thể kéo thả cùng lúc).
6. Nhấn Commit changes.
7. Vào Settings > Pages.
8. Ở Build and deployment, chọn Deploy from a branch.
9. Branch: main; folder: /(root), rồi nhấn Save.
10. Đợi GitHub Pages xuất bản. Link thường có dạng:
    https://TEN-TAI-KHOAN.github.io/thang-boss-fc-mobile/

LƯU Ý
- Không cần đưa README.txt lên nếu không muốn.
- GitHub Pages có thể mất vài phút để xuất bản lần đầu.
- Link mẫu YouTube hiện đang là link chung; thay bằng link kênh thật của bạn.
- Tùy chỉnh link ở đầu file script.js: SITE_CONFIG.channelUrl.
- Để thêm video, trong script.js, thêm các mục theo dạng:
  { title: "Tên video", description: "Mô tả", category: "GAMEPLAY", url: "https://www.youtube.com/watch?v=ID_VIDEO" }
- Để thêm Shorts, thêm các mục dạng:
  { title: "Tên Shorts", url: "https://www.youtube.com/shorts/ID_VIDEO" }
- Các tin tức hiện là bài mẫu; hãy cập nhật bằng thông tin đã kiểm chứng.
- Đây là website cộng đồng người hâm mộ, không phải trang chính thức của EA SPORTS/FC Mobile.
- Google Fonts được tải từ internet; nếu không tải được, website vẫn dùng font dự phòng.
