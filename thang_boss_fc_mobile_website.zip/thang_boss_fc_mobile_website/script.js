/*
  THẮNG BOSS FC MOBILE — cấu hình dễ chỉnh
  Thay các đường dẫn bên dưới bằng link kênh, video và Shorts thật của bạn.
  Ví dụ videoId: "dQw4w9WgXcQ" (phần sau v= trong link YouTube).
*/
const SITE_CONFIG = {
  channelUrl: "https://www.youtube.com/",
  videos: [
    // { title: "Tên video", description: "Mô tả ngắn", category: "GAMEPLAY", url: "https://www.youtube.com/watch?v=VIDEO_ID" },
  ],
  shorts: [
    // { title: "Tên Shorts", url: "https://www.youtube.com/shorts/VIDEO_ID" },
  ]
};

document.getElementById("year").textContent = new Date().getFullYear();

["navYoutube", "heroYoutube", "allVideos", "bottomYoutube"].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.href = SITE_CONFIG.channelUrl;
});

const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
menuToggle.addEventListener("click", () => {
  const open = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.textContent = open ? "✕" : "☰";
});
mainNav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  mainNav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
  menuToggle.textContent = "☰";
}));

// Nếu thêm video trong SITE_CONFIG, tự tạo thẻ có thể bấm mở YouTube.
if (SITE_CONFIG.videos.length) {
  const grid = document.getElementById("videoGrid");
  grid.innerHTML = "";
  SITE_CONFIG.videos.forEach((video, index) => {
    const card = document.createElement("article");
    card.className = "video-card";
    const link = document.createElement("a");
    link.className = "video-placeholder";
    link.href = video.url;
    link.target = "_blank";
    link.rel = "noopener";
    const play = document.createElement("span");
    play.className = "play-button";
    play.textContent = "▶";
    const label = document.createElement("span");
    label.className = "placeholder-label";
    label.textContent = video.category || "VIDEO FC MOBILE";
    const tag = document.createElement("span");
    tag.className = "corner-tag";
    tag.textContent = String(index + 1).padStart(2, "0") + " / FEATURED";
    link.append(play, label, tag);
    const info = document.createElement("div");
    info.className = "video-info";
    const category = document.createElement("span");
    category.className = "card-category";
    category.textContent = video.category || "FC MOBILE";
    const title = document.createElement("h3");
    title.textContent = video.title;
    const desc = document.createElement("p");
    desc.textContent = video.description || "Xem video trên kênh Thắng Boss FC MOBILE.";
    info.append(category, title, desc);
    card.append(link, info);
    grid.append(card);
  });
}

if (SITE_CONFIG.shorts.length) {
  const grid = document.getElementById("shortsGrid");
  grid.innerHTML = "";
  SITE_CONFIG.shorts.forEach((short, index) => {
    const link = document.createElement("a");
    link.className = "short-card" + (index ? " short-card-" + (index + 1) : "");
    link.href = short.url;
    link.target = "_blank";
    link.rel = "noopener";
    const number = document.createElement("span");
    number.className = "short-number";
    number.textContent = "SHORT / " + String(index + 1).padStart(2, "0");
    const play = document.createElement("span");
    play.className = "short-play";
    play.textContent = "▶";
    const title = document.createElement("b");
    title.textContent = short.title;
    const small = document.createElement("small");
    small.textContent = "Xem trên YouTube Shorts";
    link.append(number, play, title, small);
    grid.append(link);
  });
}
